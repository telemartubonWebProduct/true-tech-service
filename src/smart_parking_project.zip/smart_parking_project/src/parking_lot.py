from collections import deque
from typing import Dict, List, Optional, Tuple

from .models import ParkingSlot


class ParkingLot:
    def __init__(self, rows: int, cols: int) -> None:
        self.rows = rows
        self.cols = cols
        self.matrix: List[List[Optional[int]]] = [[None for _ in range(cols)] for _ in range(rows)]
        self.slots: Dict[int, ParkingSlot] = {}
        self._build_default_slots()

    def _build_default_slots(self) -> None:
        slot_id = 1
        for r in range(self.rows):
            for c in range(self.cols):
                self.add_slot(slot_id, r, c)
                slot_id += 1

    def _is_valid_cell(self, row: int, col: int) -> bool:
        return 0 <= row < self.rows and 0 <= col < self.cols

    def _neighbors(self, row: int, col: int) -> List[Tuple[int, int]]:
        dirs = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        result = []
        for dr, dc in dirs:
            nr, nc = row + dr, col + dc
            if self._is_valid_cell(nr, nc):
                result.append((nr, nc))
        return result

    def add_slot(self, slot_id: int, row: int, col: int) -> bool:
        if slot_id in self.slots:
            return False
        if not self._is_valid_cell(row, col):
            return False
        if self.matrix[row][col] is not None:
            return False

        self.slots[slot_id] = ParkingSlot(slot_id, row, col)
        self.matrix[row][col] = slot_id
        return True

    def update_slot(self, slot_id: int, new_row: int, new_col: int, is_active: bool) -> bool:
        slot = self.slots.get(slot_id)
        if slot is None:
            return False
        if not self._is_valid_cell(new_row, new_col):
            return False

        if (slot.row, slot.col) != (new_row, new_col):
            if self.matrix[new_row][new_col] is not None:
                return False
            self.matrix[slot.row][slot.col] = None
            self.matrix[new_row][new_col] = slot_id
            slot.row = new_row
            slot.col = new_col

        slot.is_active = is_active
        return True

    def delete_slot(self, slot_id: int) -> bool:
        slot = self.slots.get(slot_id)
        if slot is None or slot.is_occupied:
            return False
        self.matrix[slot.row][slot.col] = None
        del self.slots[slot_id]
        return True

    def occupy_slot(self, slot_id: int, plate_number: str) -> bool:
        slot = self.slots.get(slot_id)
        if slot is None or not slot.is_active or slot.is_occupied:
            return False
        slot.is_occupied = True
        slot.current_plate = plate_number
        return True

    def free_slot(self, slot_id: int) -> bool:
        slot = self.slots.get(slot_id)
        if slot is None or not slot.is_occupied:
            return False
        slot.is_occupied = False
        slot.current_plate = None
        return True

    def get_free_slots(self) -> List[ParkingSlot]:
        return [s for s in self.slots.values() if s.is_active and not s.is_occupied]

    def get_all_slots_sorted(self) -> List[ParkingSlot]:
        return sorted(self.slots.values(), key=lambda s: s.slot_id)

    def find_nearest_free_path(self, start_row: int = 0, start_col: int = 0):
        if not self._is_valid_cell(start_row, start_col):
            return None, []

        q = deque([(start_row, start_col)])
        visited = {(start_row, start_col)}
        parent = {(start_row, start_col): None}

        while q:
            row, col = q.popleft()
            slot_id = self.matrix[row][col]

            if slot_id is not None:
                slot = self.slots[slot_id]
                if slot.is_active and not slot.is_occupied:
                    return slot, self._reconstruct_path(parent, (row, col))

            for nr, nc in self._neighbors(row, col):
                if (nr, nc) in visited:
                    continue
                next_slot_id = self.matrix[nr][nc]
                if next_slot_id is None:
                    continue
                next_slot = self.slots[next_slot_id]
                if not next_slot.is_active or next_slot.is_occupied:
                    continue
                visited.add((nr, nc))
                parent[(nr, nc)] = (row, col)
                q.append((nr, nc))

        return None, []

    def _reconstruct_path(self, parent, end):
        path = []
        cur = end
        while cur is not None:
            path.append(cur)
            cur = parent[cur]
        path.reverse()
        return path

    def display_matrix(self) -> None:
        print('\nแผนผังที่จอดรถ')
        print('F = ว่าง, O = ไม่ว่าง, X = ปิดใช้งาน, - = ไม่มีช่องจอด')
        for row in self.matrix:
            symbols = []
            for slot_id in row:
                if slot_id is None:
                    symbols.append('-')
                    continue
                slot = self.slots[slot_id]
                if not slot.is_active:
                    symbols.append('X')
                elif slot.is_occupied:
                    symbols.append('O')
                else:
                    symbols.append('F')
            print(' '.join(symbols))
