from dataclasses import dataclass
from typing import Optional


@dataclass
class Car:
    plate_number: str
    owner_name: str
    vehicle_type: str
    slot_id: int


@dataclass
class ParkingSlot:
    slot_id: int
    row: int
    col: int
    is_active: bool = True
    is_occupied: bool = False
    current_plate: Optional[str] = None
