from typing import List, Optional

from .models import Car
from .parking_lot import ParkingLot


class SmartParkingSystem:
    def __init__(self, rows: int = 4, cols: int = 4) -> None:
        self.parking_lot = ParkingLot(rows, cols)
        self.cars: List[Car] = []

    @staticmethod
    def _plate_to_number(plate_number: str) -> int:
        value = 0
        for ch in plate_number.strip().upper():
            if ch.isdigit():
                digit = ord(ch) - ord('0')
            elif ch.isalpha():
                digit = ord(ch) - ord('A') + 10
            else:
                digit = 0
            value = value * 37 + digit
        return value

    def _find_car_index_linear(self, plate_number: str) -> int:
        target = plate_number.upper()
        for i, car in enumerate(self.cars):
            if car.plate_number == target:
                return i
        return -1

    def add_car(self, plate_number: str, owner_name: str, vehicle_type: str, slot_id: int) -> bool:
        if self._find_car_index_linear(plate_number) != -1:
            return False
        if not self.parking_lot.occupy_slot(slot_id, plate_number):
            return False
        self.cars.append(Car(plate_number.upper(), owner_name, vehicle_type, slot_id))
        return True

    def update_car(self, plate_number: str, owner_name: Optional[str] = None, vehicle_type: Optional[str] = None, slot_id: Optional[int] = None) -> bool:
        idx = self._find_car_index_linear(plate_number)
        if idx == -1:
            return False
        car = self.cars[idx]

        if slot_id is not None and slot_id != car.slot_id:
            if not self.parking_lot.occupy_slot(slot_id, car.plate_number):
                return False
            self.parking_lot.free_slot(car.slot_id)
            car.slot_id = slot_id

        if owner_name:
            car.owner_name = owner_name
        if vehicle_type:
            car.vehicle_type = vehicle_type
        return True

    def delete_car(self, plate_number: str) -> bool:
        idx = self._find_car_index_linear(plate_number)
        if idx == -1:
            return False
        car = self.cars[idx]
        self.parking_lot.free_slot(car.slot_id)
        self.cars.pop(idx)
        return True

    def bubble_sort_cars(self):
        arr = self.cars[:]
        n = len(arr)
        for i in range(n):
            swapped = False
            for j in range(0, n - i - 1):
                if self._plate_to_number(arr[j].plate_number) > self._plate_to_number(arr[j + 1].plate_number):
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
                    swapped = True
            if not swapped:
                break
        return arr

    def quick_sort_cars(self):
        arr = self.cars[:]

        def _quick_sort(low: int, high: int):
            if low >= high:
                return
            pivot = self._plate_to_number(arr[high].plate_number)
            i = low - 1
            for j in range(low, high):
                if self._plate_to_number(arr[j].plate_number) <= pivot:
                    i += 1
                    arr[i], arr[j] = arr[j], arr[i]
            arr[i + 1], arr[high] = arr[high], arr[i + 1]
            p = i + 1
            _quick_sort(low, p - 1)
            _quick_sort(p + 1, high)

        _quick_sort(0, len(arr) - 1)
        return arr

    def interpolation_search_car(self, plate_number: str):
        sorted_cars = self.quick_sort_cars()
        target = self._plate_to_number(plate_number)
        low, high = 0, len(sorted_cars) - 1

        while low <= high and sorted_cars:
            low_val = self._plate_to_number(sorted_cars[low].plate_number)
            high_val = self._plate_to_number(sorted_cars[high].plate_number)
            if low_val == high_val:
                return sorted_cars[low] if low_val == target else None

            pos = low + ((target - low_val) * (high - low) // (high_val - low_val))
            if pos < low or pos > high:
                return None
            pos_val = self._plate_to_number(sorted_cars[pos].plate_number)

            if pos_val == target:
                return sorted_cars[pos]
            if pos_val < target:
                low = pos + 1
            else:
                high = pos - 1
        return None

    def jump_search_slot(self, slot_id: int):
        slots = self.parking_lot.get_all_slots_sorted()
        n = len(slots)
        if n == 0:
            return None
        step = int(n ** 0.5)
        prev = 0

        while prev < n and slots[min(step, n) - 1].slot_id < slot_id:
            prev = step
            step += int(n ** 0.5)
            if prev >= n:
                return None

        while prev < min(step, n):
            if slots[prev].slot_id == slot_id:
                return slots[prev]
            prev += 1
        return None

    def show_free_slots(self):
        free_slots = self.parking_lot.get_free_slots()
        if not free_slots:
            print('ไม่มีช่องจอดว่าง')
            return
        print('\nช่องจอดว่าง')
        for s in sorted(free_slots, key=lambda x: x.slot_id):
            print(f'ช่อง {s.slot_id}: แถว={s.row}, คอลัมน์={s.col}')

    def show_all_parked_cars(self):
        if not self.cars:
            print('ไม่มีรถที่จอดอยู่')
            return
        print('\nรถที่จอดทั้งหมด')
        for c in self.quick_sort_cars():
            print(f'ทะเบียน={c.plate_number} | เจ้าของ={c.owner_name} | ประเภท={c.vehicle_type} | ช่องจอด={c.slot_id}')

    def show_path_to_nearest_free_slot(self, start_row: int = 0, start_col: int = 0):
        slot, path = self.parking_lot.find_nearest_free_path(start_row, start_col)
        if slot is None:
            print('ไม่พบช่องจอดว่างที่เข้าถึงได้')
            return
        print(f'ช่องว่างใกล้ที่สุด: {slot.slot_id} ที่ ({slot.row}, {slot.col})')
        print('เส้นทาง:', ' -> '.join(f'({r},{c})' for r, c in path))
