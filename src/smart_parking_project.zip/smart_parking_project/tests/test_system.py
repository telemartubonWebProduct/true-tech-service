import unittest

from src.system import SmartParkingSystem


class TestSmartParkingSystem(unittest.TestCase):
    def setUp(self):
        self.system = SmartParkingSystem(rows=3, cols=3)

    def test_add_and_search_car(self):
        ok = self.system.add_car('AB1234', 'User1', 'Sedan', 1)
        self.assertTrue(ok)
        car = self.system.interpolation_search_car('AB1234')
        self.assertIsNotNone(car)
        self.assertEqual(car.slot_id, 1)

    def test_jump_search_slot(self):
        slot = self.system.jump_search_slot(5)
        self.assertIsNotNone(slot)
        self.assertEqual(slot.slot_id, 5)

    def test_delete_car(self):
        self.system.add_car('ZZ9999', 'User2', 'SUV', 2)
        self.assertTrue(self.system.delete_car('ZZ9999'))
        self.assertIsNone(self.system.interpolation_search_car('ZZ9999'))


if __name__ == '__main__':
    unittest.main()
